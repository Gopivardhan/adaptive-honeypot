"""Honeypot core package.

This package contains all network service simulations and shared logging
infrastructure. Importing this package has no side effects.
"""
