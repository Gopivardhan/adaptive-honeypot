"""Attack detectors package.

This package includes heuristics for identifying scanning tools and classifying
clients. Additional detectors can be added here.
"""